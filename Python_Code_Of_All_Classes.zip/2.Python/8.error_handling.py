import os
import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv, find_dotenv, dotenv_values
from pprint import pprint
from pathlib import Path

#By default it will look for .env file in the current directory.
load_dotenv() 

#Error Handling for AWS Credentials
try:
    ec2_client = boto3.client('ec2')
    vpcs = ec2_client.describe_vpcs().get('Vpcs',"NotFound")
    print("TRY IS SUCCESSFUL")
    print("#"*100)
except (ValueError, KeyError, NameError, AttributeError, ClientError) as e:
    print("SINCE TRY IS FAILED, EXCEPT BLOCK IS EXECUTED")
    print(f"Error: {e}")
    print("#"*100) 
#except ValueError as e:
#    print(f"This is A Value Error: {e}")
#except KeyError as e:
#    print(f"This is A Key Error: {e}")
#except NameError as e:
#    print(f"This is A Name Error: {e}")
#except AttributeError as e:
#    print(f"This is A Attribute Error: {e}")
#except ClientError as e:
#    print(f"This is A CLIENT Error: {e}")
except Exception as e:
    #print(f"Error: {e}")
    print("Login Failed. Please check your AWS Credentials")
    print("#"*100)
    
else:
    print("SINCE TRY IS SUCCESSFUL, ELSE BLOCK IS EXECUTED")
    vpcid_list = [vpc['VpcId'] for vpc in vpcs]
    cidr_list = [ vpc['CidrBlock'] for vpc in vpcs]
    vpc_dict = dict(zip(vpcid_list, cidr_list))
    pprint(vpc_dict)
    print("#"*100) 
    
finally:
    print("This block will always be executed even if there is an exception or not.")
    print("BYE BYE!")
    print("#"*100)