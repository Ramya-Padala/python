#Meathod 1
# r for reading & r+ for both reading and writing
# w for writing & w+ for both writing and reading
# a for appending & a+ for both appending and reading
# rb for reading binary files & rb+ for both reading and writing binary files
# wb for writing binary files & wb+ for both writing and reading binary files
# ab for appending binary files & ab+ for both appending and reading binary files

#Reading a file
f = open(".env", "r") #FileNotFoundError
data = f.read()
print(data)
f.close()

#Writing & Reading a file to json
import boto3
import os
import json
#os.remove("buckets.json")
s3 = boto3.client('s3', region_name='us-east-1')
buckets = s3.list_buckets()
buckets.pop('ResponseMetadata')
f = open("buckets.json", "w+") #If you give only "w" it will throw read error as UnsupportedOperation: not readable
#default is a function applied to objects that aren't serializable.
#In this case it's str, so it just converts everything it doesn't know to strings.
f.write(json.dumps(buckets,default=str))
print(f.read())
f.close()

#Appending a file
import boto3
import os
import json
#os.remove("buckets.json")
s3 = boto3.client('s3', region_name='us-east-1')
buckets = s3.list_buckets()
buckets.pop('ResponseMetadata')
f = open("buckets.json", "a+")
#default is a function applied to objects that aren't serializable.
#In this case it's str, so it just converts everything it doesn't know to strings.
f.write(json.dumps(buckets,default=str))
f.close()




