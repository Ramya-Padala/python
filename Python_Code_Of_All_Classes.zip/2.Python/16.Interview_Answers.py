##Find the repeated characters in a string and give me the count of each character
def find_dups(string):
    char_list = []
    newstring = string.replace(" ","").lower()
    for c in newstring:
        count = newstring.count(c)
        #print(f'{c}={count}')
        char_list.append(f'{c}={count}')
        final_list = list(set(char_list))
    for item in final_list:
        print(item)
        # print(f'The character {c} is repeated {count} times')
        
#-----------------------------------------------------------------------
#Find common elements in two lists
list1 = [1,2,3,4,5]
list2 = [4,5,6,7,8,9,5,6,4,90,3,2]

for I in list1:
    count1 = list1.count(I)
    count2 = list2.count(I)
    if I in list2:
        print(f'The element {I} is common in both lists and repeated {count1+count2} times in both list')

repeated = []        
for I in list1:
    for J in list2:
        if I == J:
            repeated.append(I)
print(list(set(repeated)))

with open("servernames.log", "r") as f:
    serverlist = [s.strip() for s in f.readlines()]
    for item in serverlist:
        if serverlist.count(item) > 1:
            print(f'{item} is duplicated.')
        else:
            print(f'{item} is NOOOOOOOOOOOOOOOOOT duplicated.') 
            
##############################################
#Find Plaindrome
def is_palindrome(string):
    if string == string[::-1]:
        return True
    else:
        return False  
    
def is_palindrome(string):
    str_len = len(string)
    newstr = ''
    for I in range(str_len-1,-1,-1):
        newstr += string[I]
    print(newstr)
    if newstr == string:
        print(f'{string} is a palindrome')
    else:
        print(f'{string} is NOT a palindrome')
##############################################
#Parsing Logs with Python
62.210.215.113 - - [14/Jul/2016:16:14:13 -0400] "GET /resume/feed/ HTTP/1.1" 200 2248 "-" "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.66 Safari/537.36"
107.183.178.139 - - [14/Jul/2016:16:20:24 -0400] "GET / HTTP/1.0" 200 74545 "http://myblog.com/" "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.4.3.4000 Chrome/30.0.1599.101 Safari/537.36"
107.183.178.139 - - [14/Jul/2016:16:20:24 -0400] "GET /wp-login.php HTTP/1.1" 403 292 "http://myblog.com/" "Opera/9.80 (Windows NT 6.2; Win64; x64) Presto/2.12.388 Version/12.17"
107.183.178.139 - - [14/Jul/2016:16:20:24 -0400] "GET /wp-login.php HTTP/1.1" 403 292 "http://myblog.com/wp-login.php" "Opera/9.80 (Windows NT 6.2; Win64; x64) Presto/2.12.388Version/12.17"
107.183.178.139 - - [14/Jul/2016:16:20:25 -0400] "GET / HTTP/1.1" 200 74545 "http://myblog.com/" "PHP/5.{3|2}.{1|2|3|4|5|6|7|8|9|0}{1|2|3|4|5|6|7|8|9|0}"
107.183.178.139 - - [14/Jul/2016:16:20:25 -0400] "POST /xmlrpc.php HTTP/1.1" 403 290 "http://myblog.com/" "PHP/5.3.57"
107.183.178.139 - - [14/Jul/2016:16:20:25 -0400] "GET / HTTP/1.0" 200 74545 "-" "PHP/5.3.57"
54.234.214.67 - - [14/Jul/2016:16:23:19 -0400] "GET / HTTP/1.1" 301 - "-" "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"
54.234.214.67 - - [14/Jul/2016:16:23:19 -0400] "GET / HTTP/1.1" 200 74545 "-" "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"
54.234.214.67 - - [14/Jul/2016:16:23:19 -0400] "GET / HTTP/1.1" 301 - "-" "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"
54.234.214.67 - - [14/Jul/2016:16:23:20 -0400] "GET / HTTP/1.1" 200 74545 "-" "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"
104.202.52.41 - - [14/Jul/2016:16:28:22 -0400] "GET / HTTP/1.0" 200 74545 "-" "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.4.3.4000 Chrome/30.0.1599.101 Safari/537.36"

with open("errorlogs.txt", "r") as f:
    error_codes = []
    error_codes_count = []
    for line in f.readlines():
        error_codes.append(line.split()[8])
    for code in list(set(error_codes)):
        print(f'The Error Code {code} is repeated In The Log File For {error_codes.count(code)} times.')
    print(list(set(error_codes)))
     
    
    