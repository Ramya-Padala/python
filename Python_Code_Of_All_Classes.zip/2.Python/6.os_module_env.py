#Python Code TO Get AWS Credentials from Environment Variables
import os
import boto3
from pprint import pprint
access_key = os.getenv('AWS_ACCESS_KEY_ID')
secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')
region = os.getenv('AWS_DEFAULT_REGION')

ec2_client = boto3.client('ec2', 
                          aws_access_key_id=access_key, 
                          aws_secret_access_key=secret_key, 
                          region_name=region)
vpcs = ec2_client.describe_vpcs().get('Vpcs',"NotFound")
vpcid_list = [vpc['VpcId'] for vpc in vpcs]
cidr_list = [ vpc['CidrBlock'] for vpc in vpcs]
vpc_dict = dict(zip(vpcid_list, cidr_list))
pprint(vpc_dict)
