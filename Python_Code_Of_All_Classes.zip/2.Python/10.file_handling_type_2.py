#Writing a file to json. No option to read using w+ while using with open.
import boto3
from botocore.exceptions import ClientError
import os
import json
import uuid
#os.remove("buckets.json")
#default is a function applied to objects that aren't serializable.
#In this case it's str, so it just converts everything it doesn't know to strings.
try:
    id = str(uuid.uuid4())
    s3 = boto3.client('s3', region_name='us-east-1')
    buckets = s3.list_buckets()
    buckets.pop('ResponseMetadata')
    with open("buckets.json", "w") as f:
      f.write(json.dumps(buckets,default=str))
    s3.upload_file("buckets.json", "awsb57.xyz", f"buckets_{id}.json") 
    print("File uploaded successfully")
except ClientError as e:
    print("INVALID CREDENTIALS")
except Exception as e:
    print("File upload failed")

#Appeniding & Reading a file to json. No option to read using a+ while using with open. 
import boto3
from botocore.exceptions import ClientError
import os
import json
#os.remove("buckets.json")
#default is a function applied to objects that aren't serializable.
#In this case it's str, so it just converts data in dict to strings.
try:
    id = str(uuid.uuid4())
    s3 = boto3.client('s3', region_name='us-east-1')
    buckets = s3.list_buckets()
    buckets.pop('ResponseMetadata')
    with open("buckets.json", "a") as f:
      f.write(json.dumps(buckets,default=str))
    s3.upload_file("buckets.json", "awsb57.xyz", "buckets.json") 
    print("File uploaded successfully")
except ClientError as e:
    print("INVALID CREDENTIALS")
except Exception as e:
    print("File upload failed")
    
#Reading a file to json. No option to read using r+ while using with open.   
with open("buckets.json", "r") as f:
    data = f.read()
    print(data)

os.remove("buckets.json")
    
