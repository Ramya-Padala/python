import os
import boto3
from dotenv import load_dotenv, find_dotenv, dotenv_values
from pprint import pprint
from pathlib import Path

#By default it will look for .env file in the current directory.
load_dotenv() 

#Provide Custom path and load custom .env filename. 
#Preferance is given to load_dotenv rather than custom path.
dotenv_path = Path('.env_dev') 
load_dotenv(dotenv_path=dotenv_path)

# Prints Values from .env file in dict form.
config = dotenv_values(".env") 
print(config)
print(os.getenv('AWS_ACCESS_KEY_ID'))

ec2_client = boto3.client('ec2')
vpcs = ec2_client.describe_vpcs().get('Vpcs',"NotFound")
vpcid_list = [vpc['VpcId'] for vpc in vpcs]
cidr_list = [ vpc['CidrBlock'] for vpc in vpcs]
vpc_dict = dict(zip(vpcid_list, cidr_list))
pprint(vpc_dict)

