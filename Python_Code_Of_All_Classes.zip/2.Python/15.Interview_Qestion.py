str1 = 'Welcome To DevOps'
x = str1.replace(" ","")
for alpha in x:
    y = x.count(alpha)
    print(f'{alpha}={y}')
    
newlist = []    
for x in str1.replace(" ",""):
  t = str1.count(x)
  newlist.append(f'{x}={t}')
  updated_list = list(set(newlist))
  

def find_dups(str1):
    newlist = []
    lower = str1.lower()    
    for x in lower.replace(" ",""):
        t = lower.count(x)
        newlist.append(f'{x}={t}')
        updated_list = list(set(newlist))
    return updated_list

##############################################
list1 = [1,2,3,4,5]
list2 = [4,5,6,7,8]
for i in list1:
    if i in list2:
        print(i)
        
for i in list1:
    for j in list2:
        if i == j:
            print(i)
##############################################
