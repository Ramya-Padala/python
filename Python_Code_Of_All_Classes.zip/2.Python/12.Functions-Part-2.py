'''
Following are the diffrent types of args in python:
1. Single Positional Arguments
2. Multiple Positional Arguments
3. Default Arguments
4. Keyword Arguments
5. Variable-length Arguments using *args
6. variable-length Keyword Arguments using **kwargs
7. Forcing Positional-Only Arguments using /
8. Forcing Keyword-Only Arguments using *
'''
#==== Using Region Name as Single Positional Arguments===      
import os
import boto3
import json
from pprint import pprint
details = {}    
def getvpcs(region:str):
    ec2 = boto3.client('ec2', region_name=region)
    response = ec2.describe_vpcs().get('Vpcs')
    vpcid = [vpc['VpcId'] for vpc in response]
    cidrblock = [vpc['CidrBlock'] for vpc in response]
    return json.dumps(dict(zip(vpcid, cidrblock)))
'''
getvpcs("us-east-2") will work successfully.
getvpcs(region="us-east-2") will work successfully
'''        
#==== Using Region Name and api as Multiple Positional Arguments===
'''The values supplied during a function call are matched with 
the parameters according to their respective positions.'''
import os
import boto3
from pprint import pprint    
def getvpcs(api:str, region:str)->json:
    ec2 = boto3.client(api, region_name=region)
    response = ec2.describe_vpcs().get('Vpcs')
    vpcid = [vpc['VpcId'] for vpc in response]
    cidrblock = [vpc['CidrBlock'] for vpc in response]
    return json.dumps(dict(zip(vpcid, cidrblock)))
'''
getvpcs("ec2","us-west-2") will work successfully
getvpcs("us-west-2","ec2") will give UnknownServiceError: Unknown service: 'us-west-2'.c
'''

#==== Using Default Arguments===
'''
If you dont pass region arg as part of invoking the function, the function will assume
the default value as 'us-east-1' and api as 'ec2'
'''
import os
import boto3
from pprint import pprint    
def getvpcs(api:str="ec2", region:str="us-east-1")->json:
    ec2 = boto3.client(api, region_name=region)
    response = ec2.describe_vpcs().get('Vpcs')
    vpcid = [vpc['VpcId'] for vpc in response]
    cidrblock = [vpc['CidrBlock'] for vpc in response]
    return json.dumps(dict(zip(vpcid, cidrblock)))

#==== Using Region Name and api as Multiple Keyword Arguments===
'''The above function issuers is resolved by using Keyword args.
In Keyword Arguments, rather than depending on the argument order, 
we can explicitly mention parameter names and their corresponding 
values when invoking a function. We can change positions of the
arguments without any issues.'''

import os
import boto3
from pprint import pprint    
def getvpcs(api, region):
    ec2 = boto3.client(api, region_name=region)
    response = ec2.describe_vpcs().get('Vpcs')
    for vpc in response:
        print(vpc['VpcId'],'--->',vpc['CidrBlock'])
'''
getvpcs(region="us-east-2",api="ec2") will work successfully
getvpcs(api="ec2",region="us-east-2") will work successfully
'''


#==== Using Variable Length Arguments using *args
'''
We can use the '*' operator to allow a function to accept a variable or any number 
of positional arguments. These arguments are collected into a tuple. Args are passed
as strings or int.
'''
import os
import boto3
from pprint import pprint 
vpcs_dict_list = []   
def getvpcs(*regions):
    print(regions)
    print(type(regions))
    for region in regions:
        ec2 = boto3.client("ec2", region_name=region)
        response = ec2.describe_vpcs().get('Vpcs')
        vpcid = [vpc['VpcId'] for vpc in response]
        cidrblock = [vpc['CidrBlock'] for vpc in response]
        vpcs_dict_list.append(json.dumps(dict(zip(vpcid, cidrblock))))
    return vpcs_dict_list
    print("=====================================")
'''
getvpcs("us-west-2","us-east-1","us-east-2") will work successfully
getvpcs("us-west-2","us-east-1","us-east-2","us-west-2") will work successfully
getvpcs("us-west-2","us-east-1","us-east-2","us-west-2","ap-south-1") will work successfully
'''

#==== Using Variable Length Arguments using **kwargs
'''
The ** operator can be utilized to enable a function to handle a flexible count 
of keyword arguments. In simpler words Arbitrary keyword arguments allow you to pass an 
arbitrary number of named arguments to a function. Its called kwargs in Python.
These arguments are gathered and organized into a dictionary.
'''
def kwargs(**regions):
    print(regions)
    
import os
import boto3
from pprint import pprint    
def getvpcs(**regions):
    print(regions)
    print(type(regions))
    for key,value in regions.items():
        if key =="ec2":
            ec2 = boto3.client(key, region_name=value)
            response = ec2.describe_vpcs().get('Vpcs')
            for vpc in response:
              print(vpc['VpcId'],'--->',vpc['CidrBlock'])
            print("=====================================")
        elif key == "iam":
            iam = boto3.client(key, region_name=value)
            response = iam.list_users().get('Users')
            for user in response:
                print(user['UserName'])
            print("=====================================")
        else:
            s3 = boto3.client(key, region_name=value)
            response = s3.list_buckets().get('Buckets')
            for bucket in response:
                print(bucket['Name'])
            print("=====================================")
        
'''
getvpcs(ec2="us-east-1",s3="us-east-2",iam="us-west-1") will work successfully.
'''
#==== Forcing Positional-Only Arguments===
'''
It is possible in Python to define a function in which one or more arguments 
can not accept their value with keywords. Such arguments may be called positional-only arguments.
This means we are forcing the function to accept positional arguments only.
This is made possible using a special / symbol in how you define the function. 
'''
import os
import boto3
from pprint import pprint    
def getvpcs(api,region,/):
    ec2 = boto3.client(api, region_name=region)
    response = ec2.describe_vpcs().get('Vpcs')
    for vpc in response:
        print(vpc['VpcId'],'--->',vpc['CidrBlock'])
'''
getvpcs("ec2","us-east-1") will work successfully.
getvpcs(api="ec2",region="us-east-1") will give 
TypeError: getvpcs() got some positional-only arguments passed as keyword arguments: 'api, region'
'''

#==== Forcing Keyword-Only Arguments===
'''
Python allows us to specify certain arguments that must be passed as keyword arguments and cannot 
be used as positional arguments. This is done using the `*` syntax in function definitions.
This means we are forcing the function to accept keyword arguments only.
'''
import os
import boto3
from pprint import pprint    
def getvpcs(*,api,region):
    ec2 = boto3.client(api, region_name=region)
    response = ec2.describe_vpcs().get('Vpcs')
    for vpc in response:
        print(vpc['VpcId'],'--->',vpc['CidrBlock'])
        
'''
getvpcs("ec2","us-east-1") will give TypeError: getvpcs() takes 0 positional arguments but 2 were given.
getvpcs(api="ec2",region="us-east-1") will work successfully.
'''