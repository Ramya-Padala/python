'''
This file will cover the following topics:
1. Functions basics
2. Function Type hinting
3. Function Return vs Print
4. Calling a function from another function
'''

'''Basic Function Syntax'''
def aws_az_info():
    print('AWS AZs are us-east-1a, us-east-1b, us-east-1c')

'''
 Type hinting is a formal solution to statically indicate the type of a value within 
 your Python code. 
'''    
#RETURN vs PRINT
#Using Return
import boto3
def ret_get_az_zones(region:str)->list:
    ec2_client = boto3.client('ec2',region_name=region)
    az = ec2_client.describe_availability_zones().get('AvailabilityZones')
    az_list = [zone['ZoneName'] for zone in az]
    return az_list 

def create_volumes(region:str)->list:
    ec2_client = boto3.client('ec2',region_name=region)
    #Calling ret_get_az_zones function
    new_az_list = ret_get_az_zones(region)
    try:
        for az in new_az_list:
          ec2_client.create_volume(Size=1, AvailabilityZone=az)
    except Exception as e:
        print (f"Error: {e}")
    else:
        print("Volumes Created Successfully")
    

#Using Print for testing or debug and dont return any value.
def prt_get_az_zones(region:str)->list:
    ec2_client = boto3.client('ec2',region_name=region)
    az = ec2_client.describe_availability_zones().get('AvailabilityZones')
    az_list = [zone['ZoneName'] for zone in az]
    print(az_list)
    
